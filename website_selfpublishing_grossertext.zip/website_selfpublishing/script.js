let minutesLabel = document.getElementById("minutes"),
    secondsLabel = document.getElementById("seconds"),
    totalSeconds = 0;
setInterval(setTime, 1000);

function setTime() {
  ++totalSeconds;
  secondsLabel.innerHTML = stringIt(totalSeconds % 60);
  minutesLabel.innerHTML = stringIt(parseInt(totalSeconds / 60));
}

function stringIt(time) {
  let timeString = time + "";
  if (timeString.length < 2) {
    return `0${timeString}`;
  } else {
    return timeString;
  }
}